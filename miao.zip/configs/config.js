module.exports =  {

    wxInfo:{
        appId:"wx97d07feb75fbc40c",
        secret:"274713be472b137dcbda625022842bcb"
    },
    redisOptions: {
        host: 'localhost' ,
        port: 6379,
        // password: '123456',
        logErrors: true
    },



}
