define("pages/player_adaptor.js"/*tpa=http://res.wx.qq.com/mmbizwap/zh_CN/htmledition/js/pages/pages/player_adaptor.js*/,["pages/music_player.js"/*tpa=http://res.wx.qq.com/mmbizwap/zh_CN/htmledition/js/pages/pages/music_player.js*/,"biz_common/utils/monitor.js"/*tpa=http://res.wx.qq.com/mmbizwap/zh_CN/htmledition/js/pages/biz_common/utils/monitor.js*/,"pages/loadscript.js"/*tpa=http://res.wx.qq.com/mmbizwap/zh_CN/htmledition/js/pages/pages/loadscript.js*/,"pages/music_report_conf.js"/*tpa=http://res.wx.qq.com/mmbizwap/zh_CN/htmledition/js/pages/pages/music_report_conf.js*/],function(t){
"use strict";
function i(t,i){
0!=t.type&&1!=t.type||!p.inQMClient?"function"==typeof i.callback&&i.callback(new a.init(t)):(p.initPlayerQueue.push(n("QMClient",t,i)),
e("QMClient"));
}
function n(t,i,n){
var e=p.config[t].func;
return function(t,i,n,e){
return function(){
"function"==typeof window[i]?"function"==typeof e.callback&&e.callback(new r(n,{
type:t
})):"function"==typeof e.callback&&e.callback(new a.init(n));
};
}(t,e,i,n);
}
function e(t){
var i=p.config[t];
if(1!=i.jsLoadState){
if(2==i.jsLoadState||3==i.jsLoadState)return void s();
i.jsLoadState=1;
var n=+new Date,e=l[t+"_js_num"];
e&&(e=e.split("_"),c.setSum(e[0],e[1],1),c.send()),u({
url:i.jsLink,
timeout:1e4,
type:"JS",
callback:function(){
+new Date-n;
2==i.jsLoadState,s();
var e=l[t+"_js_suc"];
e&&(e=e.split("_"),c.setSum(e[0],e[1],1),c.send());
},
onerror:function(e){
+new Date-n;
i.jsLoadState=3,s();
var o=l[t+"_js_err"],r=l[t+"_js_timeout"],a=l[t+"_js_network"];
if(o&&r&&a){
switch(o=o.split("_"),r=r.split("_"),a=a.split("_"),c.setSum(o[0],o[1],1),1*e){
case 400:
c.setSum(a[0],a[1],1);
break;

case 500:
c.setSum(r[0],r[1],1);
}
c.send();
}
}
});
}
}
function s(){
for(var t=0,i=p.initPlayerQueue.length;i>t;t++)"function"==typeof p.initPlayerQueue[t]&&p.initPlayerQueue[t]();
p.initPlayerQueue=[];
}
function o(){
for(var t in p.config)"function"==typeof p[t+"EvInit"]&&p[t+"EvInit"]();
}
function r(t,i){
if(this.opt=t,this.opt2=i,this._g={
_blockPlugin:{},
playType:"-1"
},"QMClient"==i.type&&p.inQMClient){
var n=p.config[i.type];
n.playerObj||(p.config[i.type].playerObj=new window[n.func]),this._g.playType=i.type,
this.player=n.playerObj,this._initPlugins(),this._bindQMEvent();
}
}
var a=t("pages/music_player.js"/*tpa=http://res.wx.qq.com/mmbizwap/zh_CN/htmledition/js/pages/pages/music_player.js*/),c=t("biz_common/utils/monitor.js"/*tpa=http://res.wx.qq.com/mmbizwap/zh_CN/htmledition/js/pages/biz_common/utils/monitor.js*/),u=t("pages/loadscript.js"/*tpa=http://res.wx.qq.com/mmbizwap/zh_CN/htmledition/js/pages/pages/loadscript.js*/),l=t("pages/music_report_conf.js"/*tpa=http://res.wx.qq.com/mmbizwap/zh_CN/htmledition/js/pages/pages/music_report_conf.js*/),p={
debug:location.href.indexOf("_qqclient=1")>0?!0:!1,
config:{
QMClient:{
func:"Player",
playerObj:null,
jsLink:"https://imgcache.qq.com/music/h5/player/player.js?max_age=604800&v=1",
jsLoadState:-1
}
},
inQMClient:!1,
initPlayerQueue:[]
};
return p.QMClientEvInit=function(){
if(p.inQMClient=window.navigator.userAgent.indexOf("QQMusic/")>0||p.debug?!0:!1,
p.inQMClient&&window.msg_cdn_url&&window.msg_title){
var t=window.location.href,i=a.getQuery("scene",t);
i&&(t=t.replace("&scene="+i,"").replace("?scene="+i,"")),t=t.replace(/#rd$/,"").replace(/#wechat_redirect$/,""),
-1==t.indexOf("?")&&(t+="?"),t+="&scene=112#wechat_redirect";
var n=function(t){
window.WebViewJavascriptBridge?t():document.addEventListener("WebViewJavascriptBridgeReady",t);
},e=(window.msg_title||"").html(!1),s=(window.msg_desc||"").html(!1);
n(function(){
M.client.invoke("ui","setActionBtn",{
type:"icon",
content:"share"
},function(){
M.client.invoke("other","callShareWeb",{
imgUrl:window.msg_cdn_url,
link:t,
title:e,
desc:s
});
});
});
}
},o(),r.prototype={
_initPlugins:function(){
this.opt.plugins||(this.opt.plugins=[]);
for(var t=this.opt.plugins,i=0,n=t.length;n>i;++i){
var e=t[i];
e.setPlayer(this),!!e.init&&e.init();
}
},
_trigger:function(t,i){
var n=this.opt,e=this._g,s=n.plugins,o=e._blockPlugin[t]||e._blockPlugin.all,r=0;
if(o&&"function"==typeof o.recv&&(r|=o.recv(t,i),1&r))return!1;
for(var a=0,c=s.length;c>a&&(r|=s[a].recv(t,i),!(2&r));++a);
if(!(4&r)){
var u=this["__"+t+"Handler"];
u&&u.call(this,i);
}
8&r||this.__triggerOutside(t,i);
},
__triggerOutside:function(){
var t=arguments,i=t[0];
if(i){
i=i.substr(0,1).toUpperCase()+i.substr(1);
var n=this.opt["on"+i];
"function"==typeof n&&n.apply(this,t);
}
},
_setBlockPlugin:function(t,i){
this._g._blockPlugin[t]=i;
},
_bindQMEvent:function(){
var t=this;
this.player.on("play",function(i){
i&&i.song&&i.song.mid==t.opt.mid?(t._trigger("statusChange",1),t._trigger("QMClientPlay")):t._trigger("statusChange",3);
}),this.player.on("pause",function(i){
i&&i.song&&i.song.mid==t.opt.mid&&t._trigger("statusChange",2);
}),this.player.on("stop",function(i){
i&&i.song&&i.song.mid==t.opt.mid&&t._trigger("statusChange",3);
});
},
play:function(){
"QMClient"==this._g.playType&&this.player.play(this.opt.mid);
},
pause:function(){
this.player.pause();
},
stop:function(){
this.player.stop();
},
getDuration:function(){
return this.opt.duration?this.opt.duration:"QMClient"==this._g.playType?this.player.duration||0:0;
},
getCurTime:function(){
return"QMClient"==this._g.playType?this.player.currentTime||0:0;
},
surportSeekRange:function(){
return!1;
},
getSrc:function(){
return"";
},
destory:function(){},
seek:function(){},
setDuration:function(){},
setSrc:function(){}
},{
create:i,
inQMClient:p.inQMClient
};
});