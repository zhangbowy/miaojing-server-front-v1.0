define("biz_common/utils/report.js"/*tpa=http://res.wx.qq.com/mmbizwap/zh_CN/htmledition/js/biz_common/utils/biz_common/utils/report.js*/,[],function(){
"use strict";
return function(n){
var e=new Image;
e.src=n;
};
});